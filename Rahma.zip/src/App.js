import React from 'react';
import './App.css';
import Klasseliste from './Klasseliste.json';

function App() {
  const rader = [];

  for (let i = 0; i < Klasseliste.length; i += 3) {
    const rad = [];
    for (let j = i; j < i + 3 && j < Klasseliste.length; j++) {
      const elev = Klasseliste[j];
      rad.push(
        <div className="elev-kort" key={j}>
          <img src={elev.bilde} alt={elev.navn} />
          <h2>{elev.etternavn}</h2>
          <p>Tlf: {elev.telNummer}</p>
          <p>E-post: {elev.epostAdresse}</p>
          <p>Kjønn: {elev.kjonn}</p>
        </div>
      );
    }
    rader.push(<div className="rad" key={i}>{rad}</div>);
  }

  return (
    <div className="App">
      <h1>Klasseliste</h1>
      <div className="Klasseliste-container">
        {rader}
      </div>
    </div>
  );
}

export default App;

